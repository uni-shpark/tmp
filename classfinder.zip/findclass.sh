JAVA_HOME=/datastage/was/IBM/WebSphere/AppServer/java
CLASS_FINDER_HOME=/datastage/was/IBM/WebSphere

$JAVA_HOME/bin/java -jar $CLASS_FINDER_HOME/classfinder.jar -d $1 -c $2
