package com.uni.sellers.common;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.config.RequestConfig.Builder;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Service;

@Service("commonHTTPClient")
public class CommonHTTPClient {

	private String url;
	private Map<String,Object> commandMap;
	
	private HttpClient httpclient() {

		CloseableHttpClient httpclient = HttpClients.createDefault();
		return httpclient;

	}

	private HttpPost httppost() {

		HttpPost httpPost = new HttpPost(url);

		Builder builder = RequestConfig.custom();
		builder.setConnectTimeout(3000);
		builder.setSocketTimeout(20000);
		RequestConfig config = builder.build();

		ArrayList<NameValuePair> postParams = new ArrayList<NameValuePair>();
		for (Map.Entry<String, Object> entry : commandMap.entrySet()) {
			//postParams.add(new BasicNameValuePair(entry.getKey(), (String) entry.getValue()));
			postParams.add(new BasicNameValuePair(entry.getKey(), ""+entry.getValue()));
		}
		try {
			httpPost.setEntity(new UrlEncodedFormEntity(postParams, "UTF-8"));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		httpPost.setConfig(config);

		return httpPost;
	}

	public Object execute(String url, Map<String, Object> commandMap) {

		this.url = url;
		this.commandMap = commandMap;
		
		HttpClient httpclient = httpclient();
		HttpPost httppost = httppost();

		String responseBody = "";
		JSONParser parser = new JSONParser();

		ResponseHandler<String> responseHandler = new ResponseHandler<String>() {

			@Override
			public String handleResponse(final HttpResponse response) throws ClientProtocolException, IOException {
				int status = response.getStatusLine().getStatusCode();
				if (status >= 200 && status < 300) {
					HttpEntity entity = response.getEntity();
					String responseStr = "";
					if (entity != null) {
						responseStr = EntityUtils.toString(entity);
					}
					return responseStr;
				} else {
					throw new ClientProtocolException("Unexpected response status: " + status);
				}
			}
		};
		try {

			responseBody = httpclient.execute(httppost, responseHandler);
			System.out.println("responseBody : " + responseBody);
			return parser.parse(responseBody);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
